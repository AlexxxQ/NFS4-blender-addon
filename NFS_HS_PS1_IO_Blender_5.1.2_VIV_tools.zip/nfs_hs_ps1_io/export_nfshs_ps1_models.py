#-*- coding:utf-8 -*-

# Blender Need for Speed High Stakes (1999) PS1 exporter Add-on
# Add-on developed by PolySoupList with contributions by DGIorio


bl_info = {
	"name": "Export to Need for Speed High Stakes (1999) PS1 models format (.geo)",
	"description": "Save objects as Need for Speed High Stakes (1999) PS1 files",
	"author": "PolySoupList",
	"version": (1, 0, 0),
	"blender": (3, 6, 0),
	"location": "File > Export > Need for Speed High Stakes (1999) PS1 (.geo)",
	"warning": "",
	"wiki_url": "",
	"tracker_url": "",
	"support": "COMMUNITY",
	"category": "Import-Export"}


import bpy
from bpy.types import Operator
from bpy.props import (
	StringProperty,
	BoolProperty
)
from bpy_extras.io_utils import (
	ExportHelper,
	orientation_helper,
	axis_conversion,
)
import bmesh
import math
from mathutils import Matrix
import os
import time
import struct
import numpy as np


# Global variables
TRANSLATION_SCALE = 65536
VERTEX_SCALE = 256
NVERTEX_SCALE = 4096


def main(context, export_path, export_traffic, m, collections=None):
	os.system('cls')
	start_time = time.time()
	
	if bpy.ops.object.mode_set.poll():
		bpy.ops.object.mode_set(mode='OBJECT')
	
	for main_collection in collections if collections is not None else bpy.context.scene.collection.children:
		is_hidden = bpy.context.view_layer.layer_collection.children.get(main_collection.name).hide_viewport
		is_excluded = bpy.context.view_layer.layer_collection.children.get(main_collection.name).exclude
		
		if is_hidden or is_excluded:
			print("WARNING: skipping main collection %s since it is hidden or excluded." % (main_collection.name))
			print("")
			continue
		
		file_path = os.path.join(export_path, main_collection.name)
		
		print("Reading scene data for main collection %s..." % (main_collection.name))
		
		objects = main_collection.objects
		object_index = -1
		
		if export_traffic == False:
			try:
				header_unk0 = [id_to_int(i) for i in main_collection["header_unk0"]]
			except:
				print("WARNING: collection %s is missing parameter %s. Assuming some value (0)." % (main_collection.name, '"header_unk0"'))
				header_unk0 = [0 for _ in range(57)]
			try:
				header_unk1 = [id_to_int(i) for i in main_collection["header_unk1"]]
			except:
				print("WARNING: collection %s is missing parameter %s. Assuming some value (0)." % (main_collection.name, '"header_unk1"'))
				header_unk1 = [0 for _ in range(90)]
		else:
			header_unk0 = [0 for _ in range(57)]
			header_unk1 = [0 for _ in range(90)]
		
		object_by_index = {}
		for obj in objects:
			if obj.type == 'MESH' and "object_index" in obj:
				idx = obj["object_index"]
				if idx in object_by_index:
					print(f"WARNING: Duplicate object_index {idx}! Skipping duplicate.")
					continue
				object_by_index[idx] = obj
		
		Transformer_zObjects = []
		
		for index in range(57):
			if index in object_by_index:
				object = object_by_index[index]
				
				numVertex, numFacet, vertices, normals, faces, status, vertices_exact = read_object(object)
				
				if status == 1:
					return {'CANCELLED'}
				
				translation = Matrix(np.linalg.inv(m) @ object.matrix_world)
				translation = translation.to_translation()
				translation = [round(translation[0]*TRANSLATION_SCALE),
							   round(translation[1]*TRANSLATION_SCALE),
							   round(translation[2]*TRANSLATION_SCALE)]
				if index == 39:
					translation[0] += 0x7AE
				elif index == 40:
					translation[0] -= 0x7AE
				
				try:
					object_unk0 = id_to_int(object["object_unk0"])
				except:
					print("WARNING: object %s is missing parameter %s. Assuming some value (0)." % (object.name, '"object_unk0"'))
					object_unk0 = 0
				try:
					object_unk1 = id_to_int(object["object_unk1"])
				except:
					print("WARNING: object %s is missing parameter %s. Assuming some value (0)." % (object.name, '"object_unk1"'))
					object_unk1 = 0
				try:
					object_unk2 = id_to_int(object["object_unk2"])
				except:
					print("WARNING: object %s is missing parameter %s. Assuming some value (0)." % (object.name, '"object_unk2"'))
					object_unk2 = 0
				
				Transformer_zObj = [numVertex, numFacet, translation, object_unk0, object_unk1, object_unk2, vertices, normals, faces, vertices_exact]
			else:
				Transformer_zObj = [0, 0, [0, 0, 0], 0, 0, 0, [], [], [], []]
			
			Transformer_zObjects.append(Transformer_zObj)
		
		Transformer_zScene = [header_unk0, header_unk1, Transformer_zObjects]
		
		## Writing data
		print("\tWriting data...")
		writing_time = time.time()
		
		write_Transformer_zScene(file_path, export_traffic, Transformer_zScene)
		
		elapsed_time = time.time() - writing_time
		print("\t... %.4fs" % elapsed_time)	
	
	print("Finished")
	elapsed_time = time.time() - start_time
	print("Elapsed time: %.4fs" % elapsed_time)
	return {'FINISHED'}


def read_object(object):
	source_uv_layer = object.data.uv_layers.active
	if source_uv_layer is None:
		print("ERROR: mesh %s has no active UV layer." % object.name)
		return (0, 0, [], {}, [], 1)
	uv_layer_name = source_uv_layer.name
	# Export the edited source mesh directly when no visible modifier changes its
	# geometry. Blender's evaluated to_mesh() can expose a different active UV
	# layer, which makes otherwise valid wheel geometry sample empty atlas pixels.
	use_evaluated_mesh = any(modifier.show_viewport for modifier in object.modifiers)
	evaluated_object = None
	if use_evaluated_mesh:
		depsgraph = bpy.context.evaluated_depsgraph_get()
		evaluated_object = object.evaluated_get(depsgraph)
		mesh = evaluated_object.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
	else:
		mesh = object.data
	if mesh is None:
		print("ERROR: could not evaluate mesh %s for GEO export." % object.name)
		return (0, 0, [], {}, [], 1)
	triangulated_mesh = None
	try:
		if mesh.uv_layers.get(uv_layer_name) is None:
			print("ERROR: evaluated mesh %s does not contain its source UV layer %s." %
			      (mesh.name, uv_layer_name))
			return (0, 0, [], {}, [], 1)
		if any(len(face.vertices) > 3 for face in mesh.polygons):
			bm = bmesh.new()
			try:
				bm.from_mesh(mesh)
				bm.faces.ensure_lookup_table()
				flag_attribute = mesh.attributes.get("flag")
				if flag_attribute is not None and flag_attribute.domain == 'FACE' and flag_attribute.data_type == 'INT':
					flag_layer = bm.faces.layers.int.get("flag") or bm.faces.layers.int.new("flag")
					for face in bm.faces:
						if face.index < len(flag_attribute.data):
							face[flag_layer] = flag_attribute.data[face.index].value
				bmesh.ops.triangulate(bm, faces=[face for face in bm.faces if len(face.verts) > 3],
				                      quad_method='BEAUTY', ngon_method='BEAUTY')
				triangulated_mesh = bpy.data.meshes.new(mesh.name + "_GEO_Triangulated")
				bm.to_mesh(triangulated_mesh)
				for material in mesh.materials:
					triangulated_mesh.materials.append(material)
				triangulated_mesh.update()
			finally:
				bm.free()
			return _read_object_mesh(object, triangulated_mesh, uv_layer_name)
		return _read_object_mesh(object, mesh, uv_layer_name)
	finally:
		if triangulated_mesh is not None:
			bpy.data.meshes.remove(triangulated_mesh)
		if evaluated_object is not None:
			evaluated_object.to_mesh_clear()


def _read_object_mesh(object, mesh, uv_layer_name):
	numVertex = 0
	numFacet = 0
	vertices = []
	vertices_exact = []
	normals = {}
	faces = []
	vertices_list = {}
	vert_ind = 0
	
	# Inits
	mesh.update()
	loops = mesh.loops
	bm = bmesh.new()
	bm.from_mesh(mesh)
	
	for vert in bm.verts:
		if vert.hide == False:
			vertices_exact.append([float(vert.co[i]) * VERTEX_SCALE for i in range(3)])
			vertices.append([round(vert_co*VERTEX_SCALE) for i, vert_co in enumerate(vert.co)])
			vertices_list[vert.index] = vert_ind
			vert_ind += 1
	
	if len(vertices) > 0xFFFF:
		print("ERROR: number of vertices higher than the supported by the game on mesh %s." % mesh.name)
		return (numVertex, numFacet, vertices, normals, faces, 1, [])
	
	numVertex = len(vertices)
	
	uv_layer = mesh.uv_layers.get(uv_layer_name)
	if uv_layer is None:
		print("ERROR: mesh %s is missing UV layer %s." % (mesh.name, uv_layer_name))
		return (numVertex, numFacet, vertices, normals, faces, 1, [])
	uv_layer = uv_layer.data
	flags = mesh.attributes.get("flag")
	
	for face in mesh.polygons:
		if face.hide == True:
			continue
		
		vertexIds = []
		uvs = []
		for loop_ind in face.loop_indices:
			vert_index = vertices_list[loops[loop_ind].vertex_index]
			if vert_index not in normals:
				normals[vert_index] = loops[loop_ind].normal[:]
			
			vertexIds.append(vert_index)
			uvs.append(uv_layer[loop_ind].uv)
		
		try:
			flag = flags.data[face.index].value
		except:
			flag = 0
		
		try:
			if mesh.materials[face.material_index] == None:
				print("ERROR: face without material found on mesh %s." % mesh.name)
				return (numVertex, numFacet, vertices, normals, faces, 1, [])
		except:
			print("ERROR: face without material found on mesh %s." % mesh.name)
			return (numVertex, numFacet, vertices, normals, faces, 1, [])
		
		textureIndex = int(mesh.materials[face.material_index].name)
		
		if len(face.vertices) > 3:
			print("ERROR: non triangular face on mesh %s." % mesh.name)
			return (numVertex, numFacet, vertices, normals, faces, 1, [])
		
		vertexId0, vertexId1, vertexId2 = vertexIds
		if any(vertex_id < 0 or vertex_id > 0xFF for vertex_id in vertexIds):
			print("ERROR: PS1 GEO stores face vertex indices in one byte; mesh %s references vertex index %d." %
			      (mesh.name, max(vertexIds)))
			return (numVertex, numFacet, vertices, normals, faces, 1, [])
		
		exact_uvs = []
		for i, uv in enumerate(uvs):
			u = float(uv[0])
			v = 1.0 - float(uv[1])
			exact_uvs.extend((u, v))
			uvs[i] = int(round(uv[0]*255)) & 0xFF, int(round((1.0 - uv[1])*255)) & 0xFF
		
		uv0, uv1, uv2 = uvs
		
		faces.append([flag, textureIndex, vertexId0, vertexId1, vertexId2, uv0, uv1, uv2] + exact_uvs)
	
	if len(faces) > 0xFFFF:
		print("ERROR: number of faces higher than the supported by the game on mesh %s." % mesh.name)
		return (numVertex, numFacet, vertices, normals, faces, 1, [])
	
	numFacet = len(faces)
	
	bm.clear()
	bm.free()
	
	return (numVertex, numFacet, vertices, normals, faces, 0, vertices_exact)


def write_Transformer_zUV(f, Transformer_zUV):
	u, v = Transformer_zUV
	
	f.write(struct.pack('<B', u))
	f.write(struct.pack('<B', v))
	
	return 0


def write_Transformer_zFacet(f, Transformer_zFacet):
	flag, textureIndex, vertexId0, vertexId1, vertexId2, uv0, uv1, uv2 = Transformer_zFacet[:8]
	
	f.write(struct.pack('<h', flag))
	f.write(struct.pack('<B', textureIndex))
	f.write(struct.pack('<B', vertexId0))
	f.write(struct.pack('<B', vertexId1))
	f.write(struct.pack('<B', vertexId2))
	write_Transformer_zUV(f, uv0)
	write_Transformer_zUV(f, uv1)
	write_Transformer_zUV(f, uv2)
	
	return 0


def write_Transformer_zObj(f, export_traffic, index, Transformer_zObj):
	numVertex, numFacet, translation, unk0, unk1, unk2, vertices, normals, faces = Transformer_zObj[:9]
	
	f.write(struct.pack('<H', numVertex))
	f.write(struct.pack('<H', numFacet))
	f.write(struct.pack('<3i', *translation))
	f.write(struct.pack('<I', unk0))
	f.write(struct.pack('<I', unk1))
	f.write(struct.pack('<I', unk2))
	
	for i in range(0, numVertex):
		try:
			f.write(struct.pack('<3h', *vertices[i]))
		except:
			#print("ERROR: vertex coordinate higher than the maximum allowed. Writing zeros.")
			f.write(struct.pack("<3h", 0, 0, 0))
	if numVertex % 2 == 1:	#Data offset, happens when numVertex is odd
		f.write(struct.pack('<h', 0))
	
	if export_traffic == False:
		if get_R3DCar_ObjectInfo(index)[1] & 1 != 0:
			for i in range(0, numVertex):
				normal = normals.get(i, (0.0, 0.0, 0.0))
				Nvertex = [round(normal[0]*NVERTEX_SCALE),
						   round(normal[1]*NVERTEX_SCALE),
						   round(normal[2]*NVERTEX_SCALE)]
				f.write(struct.pack('<3h', *Nvertex))
			if numVertex % 2 == 1:	#Data offset, happens when numVertex is odd
				f.write(struct.pack('<h', 0))
	
	for i in range(0, numFacet):
		Transformer_zFacet = faces[i]
		write_Transformer_zFacet(f, Transformer_zFacet)
	
	return 0


def write_Transformer_zScene(file_path, export_traffic, Transformer_zScene):
	os.makedirs(os.path.dirname(file_path), exist_ok = True)
	
	unk0, unk1, Transformer_zObjects = Transformer_zScene
	
	with open(file_path, "wb") as f:
		f.write(struct.pack('<57I', *unk0))
		f.write(struct.pack('<90I', *unk1))
		
		for index in range(0, len(Transformer_zObjects)):
			Transformer_zObj = Transformer_zObjects[index]
			write_Transformer_zObj(f, export_traffic, index, Transformer_zObj)
		if not export_traffic:
			payload = bytearray()
			for Transformer_zObj in Transformer_zObjects:
				faces = Transformer_zObj[8]
				vertices = Transformer_zObj[6]
				vertices_exact = Transformer_zObj[9] if len(Transformer_zObj) > 9 else [[float(c) for c in v] for v in vertices]
				payload += struct.pack('<H', len(vertices_exact))
				for vertex in vertices_exact:
					payload += struct.pack('<3f', *vertex)
				payload += struct.pack('<H', len(faces))
				for face in faces:
					if len(face) < 14:
						return 1
					payload += struct.pack('<6f', *(float(face[i]) for i in range(8, 14)))
			f.write(b'NFSUV16\0')
			f.write(struct.pack('<HHI', 2, len(Transformer_zObjects), len(payload)))
			f.write(payload)
	
	return 0


def get_R3DCar_ObjectInfo(index):
	R3DCar_ObjectInfo = {0: [0x00, 0x49, 0x00, 0x01, 0x00, 0x00],
						 1: [0x00, 0x00, 0x00, 0x00, 0x01, 0x00],
						 2: [0x20, 0x02, 0x01, 0x01, 0x00, 0x00],
						 3: [0x30, 0x00, 0x01, 0x01, 0x00, 0x00],
						 4: [0xF8, 0x00, 0x00, 0x00, 0x01, 0x00],
						 5: [0xF0, 0x08, 0x0A, 0x0A, 0x00, 0x00],
						 6: [0xE0, 0x00, 0x0C, 0x00, 0x00, 0x00],
						 7: [0xE0, 0x00, 0x00, 0x0C, 0x00, 0x00],
						 8: [0xEC, 0x89, 0x0B, 0x0B, 0x00, 0x0B],
						 9: [0xF0, 0x88, 0x0B, 0x0B, 0x00, 0x0B],
						 10: [0xEC, 0x89, 0x0C, 0x0C, 0x00, 0x0C],
						 11: [0xF0, 0x88, 0x0C, 0x0C, 0x00, 0x0C],
						 12: [0xE8, 0x00, 0x01, 0x00, 0x00, 0x00],
						 13: [0xE8, 0x00, 0x00, 0x01, 0x00, 0x00],
						 14: [0xD4, 0x00, 0x11, 0x00, 0x00, 0x00],
						 15: [0xD4, 0x00, 0x11, 0x00, 0x00, 0x00],
						 16: [0xE1, 0x08, 0x01, 0x00, 0x00, 0x00],
						 17: [0xE1, 0x08, 0x00, 0x01, 0x00, 0x00],
						 18: [0xD4, 0x00, 0x12, 0x12, 0x12, 0x00],
						 19: [0xE2, 0x00, 0x01, 0x00, 0x00, 0x00],
						 20: [0xE2, 0x00, 0x00, 0x01, 0x00, 0x00],
						 21: [0xD4, 0x00, 0x13, 0x13, 0x13, 0x00],
						 22: [0xE2, 0x18, 0x0F, 0x10, 0x00, 0x00],
						 23: [0xE2, 0x08, 0x00, 0x01, 0x00, 0x00],
						 24: [0xD4, 0x10, 0x14, 0x14, 0x14, 0x00],
						 25: [0xE2, 0x18, 0x0F, 0x10, 0x00, 0x00],
						 26: [0xE2, 0x08, 0x00, 0x01, 0x00, 0x00],
						 27: [0xD4, 0x10, 0x15, 0x15, 0x15, 0x00],
						 28: [0xE8, 0x08, 0x01, 0x00, 0x00, 0x00],
						 29: [0xE8, 0x08, 0x00, 0x01, 0x00, 0x00],
						 30: [0xD4, 0x00, 0x16, 0x16, 0x16, 0x00],
						 31: [0xD8, 0x00, 0x01, 0x01, 0x00, 0x00],
						 32: [0xF4, 0x00, 0x0D, 0x00, 0x00, 0x00],
						 33: [0xF4, 0x00, 0x0E, 0x00, 0x00, 0x00],
						 34: [0xD4, 0x00, 0x11, 0x00, 0x00, 0x00],
						 35: [0x30, 0x00, 0x02, 0x01, 0x00, 0x00],
						 36: [0x28, 0x02, 0x03, 0x00, 0x00, 0x03],
						 37: [0x28, 0x02, 0x03, 0x00, 0x00, 0x03],
						 38: [0x26, 0x02, 0x04, 0x00, 0x00, 0x00],
						 39: [0x24, 0x02, 0x04, 0x00, 0x00, 0x04],
						 40: [0x24, 0x02, 0x04, 0x00, 0x00, 0x04],
						 41: [0x00, 0x49, 0x01, 0x00, 0x00, 0x01],
						 42: [0x00, 0x49, 0x01, 0x00, 0x00, 0x01],
						 43: [0xF0, 0x80, 0x05, 0x00, 0x00, 0x05],
						 44: [0xF0, 0x80, 0x06, 0x00, 0x00, 0x06],
						 45: [0xE8, 0x89, 0x07, 0x07, 0x00, 0x07],
						 46: [0xE8, 0x89, 0x08, 0x08, 0x00, 0x08],
						 47: [0x1F, 0x00, 0x01, 0x01, 0x00, 0x00],
						 48: [0x1F, 0x00, 0x01, 0x01, 0x00, 0x00],
						 49: [0x20, 0x00, 0x01, 0x00, 0x00, 0x00],
						 50: [0x20, 0x00, 0x01, 0x00, 0x00, 0x00],
						 51: [0x20, 0x00, 0x09, 0x01, 0x00, 0x00],
						 52: [0x20, 0x00, 0x09, 0x01, 0x00, 0x00],
						 53: [0x20, 0x00, 0x01, 0x00, 0x00, 0x00],
						 54: [0x20, 0x00, 0x01, 0x00, 0x00, 0x00],
						 55: [0x20, 0x00, 0x09, 0x01, 0x00, 0x00],
						 56: [0x20, 0x00, 0x09, 0x01, 0x00, 0x00]}
	
	return R3DCar_ObjectInfo[index]


def flag_encode(flag, endian):
	flag_value = 0
	
	flag_names = [
		"unknown_0",
		"unknown_1",
		"unknown_2",
		"unknown_3",
		"unknown_4",
		"unknown_5",
		"unknown_6",
		"unknown_7",
		"unknown_8",
		"unknown_9",
		"unknown_10",
		"unknown_11",
		"unknown_12",
		"unknown_13",
		"unknown_14",
		"unknown_15"
	]
	
	for i, value in enumerate(flag):
		if value:
			flag_value |= (1 << i)
	
	packed_value = (
		(flag_value & 0xFFFF)
	)
	
	flag_bytes = packed_value.to_bytes(2, byteorder=endian)
	
	return flag_bytes


def id_to_int(id):
	id_old = id
	id = id.replace('_', '')
	id = id.replace(' ', '')
	id = id.replace('-', '')
	id = ''.join(id[::-1][x:x+2][::-1] for x in range(0, len(id), 2))
	return int(id, 16)


@orientation_helper(axis_forward='-Y', axis_up='Z')
class ExportNFSHSPS1(Operator, ExportHelper):
	"""Export as a Need for Speed High Stakes (1999) PS1 Model file"""
	bl_idname = "export_nfshsps1.data"
	bl_label = "Export to folder"
	bl_options = {'PRESET'}

	filename_ext = ""
	use_filter_folder = True

	filter_glob: StringProperty(
			options={'HIDDEN'},
			default="*.geo",
			maxlen=255,
			)
	
	export_traffic: BoolProperty(
			name="Export traffic",
			description="Check in order to export a traffic vehicle",
			default=False,
		)

	
	def execute(self, context):
		userpath = self.properties.filepath
		if os.path.isfile(userpath):
			self.report({"ERROR"}, "Please select a directory not a file\n" + userpath)
			return {"CANCELLED"}
		
		global_matrix = axis_conversion(from_forward='Z', from_up='Y', to_forward=self.axis_forward, to_up=self.axis_up).to_4x4()
		
		status = main(context, self.filepath, self.export_traffic, global_matrix)
		
		if status == {"CANCELLED"}:
			self.report({"ERROR"}, "Exporting has been cancelled. Check the system console for information.")
		return status
	
	def draw(self, context):
		layout = self.layout
		layout.use_property_split = True
		layout.use_property_decorate = False  # No animation.
		
		sfile = context.space_data
		operator = sfile.active_operator
		
		##
		box = layout.box()
		split = box.split(factor=0.75)
		col = split.column(align=True)
		col.label(text="Settings", icon="SETTINGS")
		
		box.prop(operator, "export_traffic")
		
		##
		box = layout.box()
		split = box.split(factor=0.75)
		col = split.column(align=True)
		col.label(text="Blender orientation", icon="OBJECT_DATA")
		
		row = box.row(align=True)
		row.label(text="Forward axis")
		row.use_property_split = False
		row.prop_enum(operator, "axis_forward", 'X', text='X')
		row.prop_enum(operator, "axis_forward", 'Y', text='Y')
		row.prop_enum(operator, "axis_forward", 'Z', text='Z')
		row.prop_enum(operator, "axis_forward", '-X', text='-X')
		row.prop_enum(operator, "axis_forward", '-Y', text='-Y')
		row.prop_enum(operator, "axis_forward", '-Z', text='-Z')
		
		row = box.row(align=True)
		row.label(text="Up axis")
		row.use_property_split = False
		row.prop_enum(operator, "axis_up", 'X', text='X')
		row.prop_enum(operator, "axis_up", 'Y', text='Y')
		row.prop_enum(operator, "axis_up", 'Z', text='Z')
		row.prop_enum(operator, "axis_up", '-X', text='-X')
		row.prop_enum(operator, "axis_up", '-Y', text='-Y')
		row.prop_enum(operator, "axis_up", '-Z', text='-Z')


def menu_func_export(self, context):
	pcoll = preview_collections["main"]
	my_icon = pcoll["my_icon"]
	self.layout.operator(ExportNFSHSPS1.bl_idname, text="Need for Speed High Stakes (1999) PS1 (.geo)", icon_value=my_icon.icon_id)


classes = (
		ExportNFSHSPS1,
)

preview_collections = {}


def register():
	import bpy.utils.previews
	pcoll = bpy.utils.previews.new()
	
	my_icons_dir = os.path.join(os.path.dirname(__file__), "polly_icons")
	pcoll.load("my_icon", os.path.join(my_icons_dir, "nfshs_ps1_icon.png"), 'IMAGE')

	preview_collections["main"] = pcoll
	
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
	for pcoll in preview_collections.values():
		bpy.utils.previews.remove(pcoll)
	preview_collections.clear()
	
	for cls in classes:
		bpy.utils.unregister_class(cls)
	bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)


if __name__ == "__main__":
	register()
